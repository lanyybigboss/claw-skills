# HEARTBEAT.md

## Hourly Self-Check Tasks

Add these tasks to hourly heartbeat checks:

### 1. System Health Check
self-protection check

### 2. Load Monitoring
self-protection load

### 3. Resource Report
self-protection resources

### 4. Heartbeat Check
self-protection heartbeat check

### 5. Crash Log Review
self-protection crash-log last

### 6. Memory Check
```bash
MEMORY_USAGE=$(free | grep Mem | awk '{print $3/$2 * 100}')
if [ "$MEMORY_USAGE" -gt 85 ]; then
    echo "⚠️ Memory usage high: ${MEMORY_USAGE}%"
    self-protection recover
fi
```

### 7. CPU Check
```bash
CPU_USAGE=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | cut -d'%' -f1)
if [ "$CPU_USAGE" -gt 80 ]; then
    echo "⚠️ CPU usage high: ${CPU_USAGE}%"
    load-balancer check
fi
```

### 8. Disk Check
```bash
DISK_USAGE=$(df / | grep / | awk '{print $5}' | cut -d'%' -f1)
if [ "$DISK_USAGE" -gt 90 ]; then
    echo "⚠️ Disk usage high: ${DISK_USAGE}%"
    recovery log "disk" "Disk usage exceeded threshold"
fi
```

### 9. Process Check
```bash
OPENCLAW_STATUS=$(ps aux | grep openclaw | grep -v grep | wc -l)
if [ "$OPENCLAW_STATUS" -eq 0 ]; then
    echo "⚠️ OpenClaw not running"
    self-protection recover --force
fi
```

### 10. Network Check
```bash
NETWORK_TEST=$(ping -c 1 -W 1 docs.openclaw.ai 2>/dev/null | grep "time=" | awk -F'=' '{print $4}' | cut -d' ' -f1)
if [ -z "$NETWORK_TEST" ]; then
    echo "⚠️ Network connectivity issue"
    recovery log "network" "Network connectivity lost"
fi
```

## Heartbeat Scheduling

Hourly heartbeat checks are scheduled via cron:
```bash
(crontab -l 2>/dev/null; echo "0 * * * * $HOME/.openclaw/workspace/skills/self-protection/scripts/heartbeat.sh check") | crontab -
```